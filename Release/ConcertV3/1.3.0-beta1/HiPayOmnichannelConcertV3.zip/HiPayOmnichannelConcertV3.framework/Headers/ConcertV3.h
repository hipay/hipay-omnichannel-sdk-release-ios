//
//  ConcertV3.h
//  ConcertV3
//
//  Author support@hipay.com.
//  Copyright HiPay 2019-2021
//

#import <UIKit/UIKit.h>

//! Project version number for ConcertV3.
FOUNDATION_EXPORT double ConcertV3VersionNumber;

//! Project version string for ConcertV3.
FOUNDATION_EXPORT const unsigned char ConcertV3VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConcertV3/PublicHeader.h>
